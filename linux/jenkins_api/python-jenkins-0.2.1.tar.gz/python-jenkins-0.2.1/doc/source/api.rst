:title: API reference

API reference
=============

.. automodule:: jenkins
    :members:
    :undoc-members:
