Welcome to Python Jenkins's documentation!
==========================================

Python Jenkins is a library for the remote API of the `Jenkins
<http://jenkins-ci.org/>`_ continuous integration server. It is useful
for creating and managing jobs as well as build nodes.

Table of content:

.. toctree::
    :maxdepth: 2
    :glob:

    *

Python Jenkins development is hosted on Launchpad: https://launchpad.net/python-jenkins

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
